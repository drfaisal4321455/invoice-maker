import Link from 'next/link';
import { PlusCircle, MoreHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { company } from '@/lib/data';
import { formatCurrency } from '@/lib/utils';
import { PageHeader } from '@/components/page-header';
import { getInvoices } from '@/lib/firebase/invoices';
import { getCustomers } from '@/lib/firebase/customers';

export default async function DashboardPage() {
  const invoices = await getInvoices();
  const customers = await getCustomers();
  
  const getCustomerName = (id: string) => customers.find(c => c.id === id)?.name || 'Unknown';
  const getCustomerEmail = (id: string) => customers.find(c => c.id === id)?.email;

  const statusVariant = {
    paid: 'default',
    unpaid: 'destructive',
    draft: 'secondary',
  } as const;


  return (
    <div className="space-y-4">
      <PageHeader title="Dashboard" description="An overview of your recent invoices.">
        <Button asChild>
          <Link href="/invoices/new">
            <PlusCircle />
            Create Invoice
          </Link>
        </Button>
      </PageHeader>
      <Card>
        <CardHeader>
          <CardTitle>Invoices</CardTitle>
          <CardDescription>A list of your recent invoices.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead className="hidden md:table-cell">Date</TableHead>
                <TableHead>
                  <span className="sr-only">Actions</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoices.map((invoice) => (
                <TableRow key={invoice.id}>
                  <TableCell>
                    <div className="font-medium">{getCustomerName(invoice.customerId)}</div>
                    <div className="text-sm text-muted-foreground hidden md:inline">
                      {getCustomerEmail(invoice.customerId)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={statusVariant[invoice.status] || 'outline'} className="capitalize">{invoice.status}</Badge>
                  </TableCell>
                  <TableCell className="text-right">{formatCurrency(invoice.total, company.currency)}</TableCell>
                  <TableCell className="hidden md:table-cell">{new Date(invoice.issueDate).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button aria-haspopup="true" size="icon" variant="ghost">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Toggle menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem>Edit</DropdownMenuItem>
                        <DropdownMenuItem>Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
