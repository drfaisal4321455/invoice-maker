import { CustomerForm } from "@/components/customer-form";
import { PageHeader } from "@/components/page-header";

export default function NewCustomerPage() {
  return (
    <div className="space-y-4 pb-8">
      <PageHeader title="Create Customer" description="Fill out the details to create a new customer." />
      <CustomerForm />
    </div>
  );
}
