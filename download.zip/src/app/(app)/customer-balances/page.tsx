import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { company } from '@/lib/data';
import { formatCurrency } from '@/lib/utils';
import { PageHeader } from '@/components/page-header';
import { getCustomers } from '@/lib/firebase/customers';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Eye } from 'lucide-react';

export default async function CustomerBalancesPage() {
  const customers = await getCustomers();

  return (
    <div className="space-y-4">
      <PageHeader title="Customer Balances" description="View outstanding balances for all customers." />
      <Card>
        <CardHeader>
          <CardTitle>Balances</CardTitle>
          <CardDescription>A list of all customers and their outstanding balances.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead>Email</TableHead>
                <TableHead className="text-right">Outstanding Balance</TableHead>
                <TableHead><span className="sr-only">Actions</span></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {customers.map((customer) => (
                <TableRow key={customer.id}>
                  <TableCell>
                    <div className="font-medium">{customer.name}</div>
                  </TableCell>
                  <TableCell>{customer.email}</TableCell>
                  <TableCell className="text-right">
                    <Badge variant={customer.ledgerBalance > 0 ? 'destructive' : 'default'}>
                      {formatCurrency(customer.ledgerBalance, company.currency)}
                    </Badge>
                  </TableCell>
                   <TableCell className="text-right">
                      <Button variant="outline" size="sm" asChild>
                        <Link href={`/customers/${customer.id}`}>
                          <Eye className="mr-2 h-4 w-4" /> View Details
                        </Link>
                      </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
