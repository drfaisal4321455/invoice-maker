import { redirect } from 'next/navigation';

export default function InvoicesPage() {
  // The dashboard is the main invoices list
  redirect('/dashboard');
}
