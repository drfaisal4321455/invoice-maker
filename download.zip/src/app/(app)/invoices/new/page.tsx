import { InvoiceForm } from "@/components/invoice-form";
import { PageHeader } from "@/components/page-header";

export default function NewInvoicePage() {
  return (
    <div className="space-y-4 pb-8">
      <PageHeader title="Create Invoice" description="Fill out the details to create a new invoice." />
      <InvoiceForm />
    </div>
  );
}
