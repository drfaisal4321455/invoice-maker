'use server';

import {
  invoiceCompletenessCheck,
  type InvoiceCompletenessCheckInput,
} from '@/ai/flows/invoice-completeness-check';
import { company } from '@/lib/data';
import type { z } from 'zod';
import { createInvoiceSchema } from '@/components/invoice-form';
import { getCustomers } from '@/lib/firebase/customers';
import { triggerBackup as triggerBackupFlow } from '@/ai/flows/backup-flow';

export async function checkInvoiceCompleteness(
  invoiceData: z.infer<typeof createInvoiceSchema>
) {
  try {
    const customers = await getCustomers();
    const customer = customers.find((c) => c.id === invoiceData.customerId);

    const subtotal = invoiceData.items.reduce((acc, item) => acc + item.quantity * item.price, 0);
    const discountAmount = subtotal * ( (invoiceData.globalDiscount || 0) / 100);
    const subtotalAfterDiscount = subtotal - discountAmount;
    const total = subtotalAfterDiscount + (invoiceData.shipping || 0);

    const aiInput: InvoiceCompletenessCheckInput = {
      companyName: company.name,
      customerName: customer?.name || 'Unknown Customer',
      invoiceNumber: invoiceData.invoiceNumber,
      issueDate: invoiceData.issueDate.toISOString().split('T')[0],
      dueDate: invoiceData.dueDate.toISOString().split('T')[0],
      items: invoiceData.items.map((item) => {
        return {
          sku: item.itemId,
          description: 'Item',
          quantity: item.quantity,
          price: item.price,
        };
      }),
      subtotal: subtotal,
      globalDiscount: invoiceData.globalDiscount,
      shipping: invoiceData.shipping,
      total: total,
    };

    const result = await invoiceCompletenessCheck(aiInput);
    return result;
  } catch (error) {
    console.error('Error checking invoice completeness:', error);
    return {
      isComplete: false,
      missingFields: [],
      potentialOmissions: [],
      reasoning: 'An unexpected error occurred while analyzing the invoice with AI. Please try again.',
    };
  }
}

export async function triggerBackup() {
  try {
    const result = await triggerBackupFlow();
    return result;
  } catch (error) {
    console.error('Error triggering backup:', error);
    return {
      success: false,
      message: 'An unexpected error occurred while triggering the backup.',
    };
  }
}
