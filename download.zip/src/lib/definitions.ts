import { Timestamp } from 'firebase/firestore';

export type Company = {
  id: string;
  name: string;
  logoUrl: string;
  phone: string;
  email: string;
  address: string;
  taxInfo: string;
  currency: string;
};

export type Customer = {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  ledgerBalance: number;
};

export type FirestoreCustomer = Omit<Customer, 'id' | 'ledgerBalance'>;

export type Item = {
  id: string;
  sku: string;
  description: string;
  price: number;
  taxRate: number;
};

export type InvoiceItem = {
  itemId: string;
  quantity: number;
  price: number;
  tax: number;
  discount: number;
};

export type InvoiceStatus = 'draft' | 'sent' | 'paid' | 'unpaid' | 'returned';

export type Invoice = {
  id:string;
  invoiceNumber: string;
  customerId: string;
  issueDate: string;
  dueDate: string;
  items: InvoiceItem[];
  subtotal: number;
  globalDiscount: number;
  shipping: number;
  total: number;
  status: InvoiceStatus;
};

export type FirestoreInvoice = {
  invoiceNumber: string;
  customerId: string;
  issueDate: Timestamp;
  dueDate: Timestamp;
  items: {
    itemId: string;
    quantity: number;
    price: number;
  }[];
  subtotal: number;
  globalDiscount: number;
  shipping: number;
  total: number;
  status: InvoiceStatus;
};

export type InvoiceTemplate = {
  id: string;
  name: string;
  className: string;
};
