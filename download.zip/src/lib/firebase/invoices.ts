'use server';

import { collection, getDocs, query, collectionGroup } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Invoice, FirestoreInvoice } from '@/lib/definitions';

export async function getInvoices(): Promise<Invoice[]> {
    const invoicesCol = collectionGroup(db, 'invoices');
    const q = query(invoicesCol);
    const invoiceSnapshot = await getDocs(q);
    const invoiceList = invoiceSnapshot.docs.map(doc => {
        const data = doc.data() as FirestoreInvoice;
        return {
            id: doc.id,
            ...data,
            issueDate: data.issueDate.toDate().toISOString(),
            dueDate: data.dueDate.toDate().toISOString(),
        } as Invoice;
    });
    return invoiceList;
}
