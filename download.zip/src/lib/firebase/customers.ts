'use server';
import { collection, getDocs, doc, getDoc, query, where, getDocs as getSubDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { Customer, FirestoreCustomer, Invoice, FirestoreInvoice } from '@/lib/definitions';

export async function getCustomers(): Promise<Customer[]> {
  const customersCol = collection(db, 'customers');
  const customerSnapshot = await getDocs(customersCol);
  const customerList = customerSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Customer));

  const customersWithBalances = await Promise.all(
    customerList.map(async (customer) => {
      const invoicesCol = collection(db, 'customers', customer.id, 'invoices');
      const q = query(invoicesCol, where('status', '==', 'unpaid'));
      const unpaidInvoicesSnapshot = await getSubDocs(q);
      const balance = unpaidInvoicesSnapshot.docs.reduce((acc, doc) => acc + doc.data().total, 0);
      return { ...customer, ledgerBalance: balance };
    })
  );

  return customersWithBalances;
}

export async function getCustomer(id: string): Promise<Customer | null> {
  const customerRef = doc(db, 'customers', id);
  const customerSnap = await getDoc(customerRef);

  if (customerSnap.exists()) {
    const customerData = customerSnap.data() as FirestoreCustomer;
    const invoicesCol = collection(db, 'customers', id, 'invoices');
    const q = query(invoicesCol, where('status', '==', 'unpaid'));
    const unpaidInvoicesSnapshot = await getSubDocs(q);
    const balance = unpaidInvoicesSnapshot.docs.reduce((acc, doc) => acc + doc.data().total, 0);
    return { id: customerSnap.id, ...customerData, ledgerBalance: balance };
  } else {
    return null;
  }
}
