import type { Company, Customer, Item, Invoice, InvoiceStatus } from './definitions';

export const company: Company = {
  id: '1',
  name: 'Innovate Inc.',
  logoUrl: 'https://picsum.photos/seed/logo/100/100',
  phone: '123-456-7890',
  email: 'contact@innovateinc.com',
  address: '123 Innovation Drive, Tech City, 12345',
  taxInfo: 'VAT ID: 123456789',
  currency: 'PKR',
};

export const customers: Customer[] = [];

export const items: Item[] = [
  {
    id: 'item_1',
    sku: 'WEB-DEV-01',
    description: 'Website Development (Basic)',
    price: 420000,
    taxRate: 0.08,
  },
  {
    id: 'item_2',
    sku: 'GRAPH-DES-01',
    description: 'Logo Design Package',
    price: 140000,
    taxRate: 0.08,
  },
  {
    id: 'item_3',
    sku: 'SEO-CONS-01',
    description: 'SEO Consulting (Monthly)',
    price: 210000,
    taxRate: 0,
  },
  {
    id: 'item_4',
    sku: 'MAINT-PLAN-01',
    description: 'Website Maintenance (Annual)',
    price: 336000,
    taxRate: 0.08,
  },
];

export const invoices: Invoice[] = [];
