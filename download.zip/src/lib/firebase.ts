// src/lib/firebase.ts
import { initializeApp, getApp, getApps } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  projectId: "studio-4326290413-a3133",
  appId: "1:666798936937:web:0760e6b34ab1b65041a3f8",
  apiKey: "AIzaSyB-vlq0eWknnzya1VoNeDkj0LxFj6eLbWI",
  authDomain: "studio-4326290413-a3133.firebaseapp.com",
  measurementId: "",
  messagingSenderId: "666798936937"
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);

export { app, db };
