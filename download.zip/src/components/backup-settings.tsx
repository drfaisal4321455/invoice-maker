'use client';

import { useState, useTransition } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Loader2,
  Cloud,
  HardDriveDownload,
  History,
  AlertCircle,
} from 'lucide-react';
import { triggerBackup } from '@/app/actions';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';

type Backup = {
  date: string;
  files: string[];
};

const dummyBackups: Backup[] = [
  { date: '2023-10-26', files: ['customers.json', 'invoices.json'] },
  { date: '2023-10-25', files: ['customers.json', 'invoices.json'] },
  { date: '2023-10-24', files: ['customers.json', 'invoices.json'] },
];

export function BackupSettings() {
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  const handleManualBackup = () => {
    startTransition(async () => {
      const result = await triggerBackup();
      if (result.success) {
        toast({
          title: 'Backup Successful',
          description: result.message,
        });
      } else {
        toast({
          title: 'Backup Failed',
          description: result.message,
          variant: 'destructive',
        });
      }
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Backup & Restore</CardTitle>
        <CardDescription>
          Manage your data backups. Backups are stored securely in Firebase
          Cloud Storage.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="font-medium">Automatic Backups</h3>
          <div className="flex items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <Label htmlFor="auto-backup-switch" className="text-base">
                Enable Automatic Backups
              </Label>
              <p className="text-sm text-muted-foreground">
                Backups will run automatically based on your chosen frequency.
              </p>
            </div>
            <Switch id="auto-backup-switch" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="backup-frequency">Backup Frequency</Label>
            <Select defaultValue="daily">
              <SelectTrigger id="backup-frequency" className="w-[180px]">
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-medium">Manual Backup</h3>
          <p className="text-sm text-muted-foreground">
            Create a backup of your current data at any time.
          </p>
          <Button onClick={handleManualBackup} disabled={isPending}>
            {isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Cloud className="mr-2 h-4 w-4" />
            )}
            Trigger Manual Backup
          </Button>
        </div>

        <div className="space-y-4">
          <h3 className="font-medium">Backup History</h3>
           <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Cloud Function Required</AlertTitle>
              <AlertDescription>
                Automated backups and restoring from history requires setting up a scheduled Cloud Function in your Firebase project. The manual trigger is functional.
              </AlertDescription>
            </Alert>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Backup Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dummyBackups.map((backup) => (
                <TableRow key={backup.date}>
                  <TableCell>
                    <div className="font-medium">
                      {new Date(backup.date).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {backup.files.join(', ')}
                    </div>
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button variant="outline" size="sm" disabled>
                      <History className="mr-2 h-4 w-4" />
                      Restore
                    </Button>
                    <Button variant="outline" size="sm" disabled>
                      <HardDriveDownload className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
