'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useFieldArray, useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { items as allItems, company } from '@/lib/data';
import { cn, formatCurrency } from '@/lib/utils';
import { CalendarIcon, PlusCircle, Trash2, Eye, Printer, Share2, ImageIcon, BellRing } from 'lucide-react';
import { format } from 'date-fns';
import { useEffect, useState, useRef } from 'react';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from './ui/sheet';
import { InvoicePreview } from './invoice-preview';
import { InvoiceAIChecker } from './invoice-ai-checker';
import { Separator } from './ui/separator';
import { getCustomers } from '@/lib/firebase/customers';
import type { Customer, InvoiceTemplate } from '@/lib/definitions';
import { toPng } from 'html-to-image';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { InvoiceTemplateSelector } from './invoice-template-selector';

export const createInvoiceSchema = z.object({
  invoiceNumber: z.string().min(1, 'Invoice number is required.'),
  customerId: z.string().min(1, 'Customer is required.'),
  issueDate: z.date(),
  dueDate: z.date(),
  items: z.array(
    z.object({
      itemId: z.string().min(1, 'Item is required.'),
      quantity: z.coerce.number().min(1, 'Quantity must be at least 1.'),
      price: z.coerce.number().min(0, 'Price cannot be negative.'),
      discount: z.coerce.number().min(0, 'Discount cannot be negative.').optional().default(0),
    })
  ).min(1, 'At least one item is required.'),
  globalDiscount: z.coerce.number().min(0).max(100).optional().default(0),
  shipping: z.coerce.number().min(0).optional().default(0),
});

const invoiceTemplates: InvoiceTemplate[] = [
  { id: 'template-1', name: 'Classic', className: 'template-classic' },
  { id: 'template-2', name: 'Modern', className: 'template-modern' },
  { id: 'template-3', name: 'Minimalist', className: 'template-minimalist' },
  { id: 'template-4', name: 'Corporate', className: 'template-corporate' },
  { id: 'template-5', name: 'Creative', className: 'template-creative' },
  { id: 'template-6', name: 'Elegant', className: 'template-elegant' },
  { id: 'template-7', name: 'Bold', className: 'template-bold' },
  { id: 'template-8', name: 'Formal', className: 'template-formal' },
  { id: 'template-9', name: 'Friendly', className: 'template-friendly' },
  { id: 'template-10', name: 'Tech', className: 'template-tech' },
];

export function InvoiceForm() {
  const [sheetOpen, setSheetOpen] = useState(false);
  const [isClient, setIsClient] = useState(false);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<InvoiceTemplate>(invoiceTemplates[0]);
  const invoicePreviewRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setIsClient(true);
    async function fetchCustomers() {
      const customerData = await getCustomers();
      setCustomers(customerData);
    }
    fetchCustomers();
  }, []);
  
  const form = useForm<z.infer<typeof createInvoiceSchema>>({
    resolver: zodResolver(createInvoiceSchema),
    defaultValues: {
      invoiceNumber: '',
      // issueDate and dueDate are now initialized without `new Date()`
      items: [{ itemId: '', quantity: 1, price: 0, discount: 0 }],
      globalDiscount: 0,
      shipping: 0,
    },
  });

  useEffect(() => {
    if (isClient) {
      form.reset({
        ...form.getValues(),
        invoiceNumber: `INV-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000)}`,
        issueDate: new Date(),
        dueDate: new Date(new Date().setDate(new Date().getDate() + 30)),
      });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isClient]);

  const { fields, append, remove, update } = useFieldArray({
    control: form.control,
    name: 'items',
  });

  const watchedItems = form.watch('items');
  const watchedGlobalDiscount = form.watch('globalDiscount');
  const watchedShipping = form.watch('shipping');

  const subtotal = watchedItems.reduce((acc, item) => acc + (item.quantity * item.price), 0);
  const discountAmount = subtotal * (watchedGlobalDiscount / 100);
  const subtotalAfterDiscount = subtotal - discountAmount;
  const totalTax = watchedItems.reduce((acc, item) => {
    const product = allItems.find(p => p.id === item.itemId);
    return acc + (item.quantity * item.price * (product?.taxRate || 0));
  }, 0);
  const total = subtotalAfterDiscount + totalTax + watchedShipping;

  function onSubmit(data: z.infer<typeof createInvoiceSchema>) {
    console.log(data);
    // Here you would typically send the data to your backend
    alert('Invoice created successfully! (Check console for data)');
  }
  
  const handlePrint = () => {
    window.print();
  };
  
  const handleDownloadImage = async () => {
    if (invoicePreviewRef.current) {
      const dataUrl = await toPng(invoicePreviewRef.current);
      const link = document.createElement('a');
      link.download = `invoice-${form.getValues('invoiceNumber')}.png`;
      link.href = dataUrl;
      link.click();
    }
  };
  
  const handleShareWhatsApp = () => {
    const invoiceData = form.getValues();
    const customer = customers.find(c => c.id === invoiceData.customerId);
    const message = `
      Hi ${customer?.name || ''},
      
      Here is your invoice ${invoiceData.invoiceNumber} for ${formatCurrency(total, company.currency)}.
      
      Due Date: ${format(invoiceData.dueDate, 'PPP')}
      
      Thank you,
      ${company.name}
    `.trim().replace(/\s+/g, ' ');

    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };


  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Invoice Details</CardTitle>
              <CardDescription>Enter the main details for your invoice.</CardDescription>
            </CardHeader>
            <CardContent className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <FormField
                control={form.control}
                name="invoiceNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Invoice Number</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="customerId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Customer</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a customer" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {customers.map((customer) => (
                          <SelectItem key={customer.id} value={customer.id}>
                            {customer.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="issueDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Issue Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={'outline'}
                            className={cn(
                              'w-full pl-3 text-left font-normal',
                              !field.value && 'text-muted-foreground'
                            )}
                          >
                            {field.value ? (
                              format(field.value, 'PPP')
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Due Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={'outline'}
                            className={cn(
                              'w-full pl-3 text-left font-normal',
                              !field.value && 'text-muted-foreground'
                            )}
                          >
                            {field.value ? (
                              format(field.value, 'PPP')
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Line Items</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {fields.map((field, index) => {
                const selectedItem = allItems.find(item => item.id === watchedItems[index]?.itemId);
                
                return (
                  <div key={field.id} className="grid grid-cols-12 gap-4 items-start">
                    <div className="col-span-12 md:col-span-4">
                      <FormField
                        control={form.control}
                        name={`items.${index}.itemId`}
                        render={({ field }) => (
                          <FormItem>
                            {index === 0 && <FormLabel>Item</FormLabel>}
                            <Select
                              onValueChange={(value) => {
                                field.onChange(value);
                                const selected = allItems.find(item => item.id === value);
                                if (selected) {
                                  update(index, { ...watchedItems[index], price: selected.price });
                                }
                              }}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select an item" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {allItems.map(item => (
                                  <SelectItem key={item.id} value={item.id}>
                                    {item.description}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name={`items.${index}.quantity`}
                      render={({ field }) => (
                        <FormItem className="col-span-4 md:col-span-2">
                          {index === 0 && <FormLabel>Quantity</FormLabel>}
                          <FormControl>
                            <Input type="number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name={`items.${index}.price`}
                      render={({ field }) => (
                        <FormItem className="col-span-4 md:col-span-2">
                          {index === 0 && <FormLabel>Price</FormLabel>}
                          <FormControl>
                            <Input type="number" {...field} readOnly />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="col-span-4 md:col-span-3 flex items-center h-full">
                       {index === 0 && <FormLabel className="md:hidden">Total</FormLabel>}
                       <p className="font-medium mt-2 md:mt-8 w-full text-right md:text-left">{formatCurrency(watchedItems[index]?.quantity * watchedItems[index]?.price || 0, company.currency)}</p>
                    </div>

                    <div className="col-span-12 md:col-span-1 flex items-end justify-end h-full">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:bg-destructive/10"
                        onClick={() => remove(index)}
                        disabled={fields.length <= 1}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
              <Button
                type="button"
                variant="outline"
                onClick={() => append({ itemId: '', quantity: 1, price: 0, discount: 0 })}
                className="mt-4"
              >
                <PlusCircle className="mr-2 h-4 w-4" /> Add Item
              </Button>
            </CardContent>
          </Card>
          
          <div className="flex flex-wrap gap-6 justify-between">
            <Card className="flex-1 min-w-[250px]">
              <CardHeader>
                <CardTitle>Summary Adjustments</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="globalDiscount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Global Discount (%)</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="shipping"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Shipping Cost</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            <Card className="flex-1 min-w-[250px] bg-secondary/50">
              <CardHeader>
                <CardTitle>Total Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span>{formatCurrency(subtotal, company.currency)}</span>
                </div>
                {watchedGlobalDiscount > 0 &&
                  <div className="flex justify-between text-muted-foreground">
                    <span>Discount</span>
                    <span>- {formatCurrency(discountAmount, company.currency)}</span>
                  </div>
                }
                <div className="flex justify-between text-muted-foreground">
                  <span>Tax</span>
                  <span>{formatCurrency(totalTax, company.currency)}</span>
                </div>
                {watchedShipping > 0 &&
                  <div className="flex justify-between text-muted-foreground">
                    <span>Shipping</span>
                    <span>{formatCurrency(watchedShipping, company.currency)}</span>
                  </div>
                }
                <Separator />
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span>{formatCurrency(total, company.currency)}</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-end gap-2 pt-4">
             <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
                <SheetTrigger asChild>
                    <Button type="button" variant="outline"><Eye className="mr-2 h-4 w-4" /> Preview & Check</Button>
                </SheetTrigger>
                <SheetContent className="w-full sm:max-w-5xl overflow-y-auto">
                    <SheetHeader>
                        <SheetTitle>Invoice Preview & Actions</SheetTitle>
                        <SheetDescription>
                            Review the invoice, check for errors with AI, and perform actions like printing or sharing.
                        </SheetDescription>
                    </SheetHeader>
                    <div className="grid md:grid-cols-3 gap-6 py-4">
                        <div className="md:col-span-2">
                          <InvoicePreview 
                            ref={invoicePreviewRef} 
                            invoiceData={form.getValues()} 
                            customers={customers}
                            templateClassName={selectedTemplate.className}
                          />
                        </div>
                        <div className="md:col-span-1 space-y-4 no-print">
                          <InvoiceTemplateSelector 
                            templates={invoiceTemplates}
                            selectedTemplate={selectedTemplate}
                            onTemplateSelect={setSelectedTemplate}
                          />
                          <Card>
                            <CardHeader>
                              <CardTitle>Actions</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                               <Button onClick={handleShareWhatsApp} className="w-full" variant="outline">
                                <Share2 className="mr-2 h-4 w-4"/>
                                Share on WhatsApp
                              </Button>
                              <Button onClick={handleDownloadImage} className="w-full" variant="outline">
                                <ImageIcon className="mr-2 h-4 w-4"/>
                                Download as Image
                              </Button>
                              <Button onClick={handlePrint} className="w-full">
                                <Printer className="mr-2 h-4 w-4"/>
                                Print / Download PDF
                              </Button>
                              <div className="flex items-center justify-between pt-4">
                                <Label htmlFor="auto-reminder" className="flex items-center gap-2">
                                  <BellRing className="h-4 w-4"/>
                                  <span>Auto Reminder</span>
                                </Label>
                                <Switch id="auto-reminder" />
                              </div>
                            </CardContent>
                          </Card>
                          <InvoiceAIChecker invoiceData={form.getValues()} />
                        </div>
                    </div>
                </SheetContent>
            </Sheet>
            <Button type="submit">Save Invoice</Button>
          </div>
        </form>
      </Form>
    </>
  );
}
