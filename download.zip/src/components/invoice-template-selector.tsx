'use client';

import type { InvoiceTemplate } from '@/lib/definitions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

type InvoiceTemplateSelectorProps = {
  templates: InvoiceTemplate[];
  selectedTemplate: InvoiceTemplate;
  onTemplateSelect: (template: InvoiceTemplate) => void;
};

export function InvoiceTemplateSelector({ templates, selectedTemplate, onTemplateSelect }: InvoiceTemplateSelectorProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Select a Template</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="w-full whitespace-nowrap">
          <div className="flex space-x-4 pb-4">
            {templates.map((template) => (
              <div
                key={template.id}
                className={cn(
                  'w-24 h-32 rounded-md border-2 flex-shrink-0 cursor-pointer flex items-center justify-center text-center p-2',
                  selectedTemplate.id === template.id ? 'border-primary' : 'border-border'
                )}
                onClick={() => onTemplateSelect(template)}
              >
                <span className="text-xs font-medium">{template.name}</span>
              </div>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
