'use client';

import { useState, useTransition } from 'react';
import type { z } from 'zod';
import { Button } from './ui/button';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { checkInvoiceCompleteness } from '@/app/actions';
import type { createInvoiceSchema } from './invoice-form';
import type { InvoiceCompletenessCheckOutput } from '@/ai/flows/invoice-completeness-check';
import { Loader2, CheckCircle, AlertTriangle, Info } from 'lucide-react';

type InvoiceAICheckerProps = {
  invoiceData: z.infer<typeof createInvoiceSchema>;
};

export function InvoiceAIChecker({ invoiceData }: InvoiceAICheckerProps) {
  const [isPending, startTransition] = useTransition();
  const [result, setResult] = useState<InvoiceCompletenessCheckOutput | null>(null);

  const handleCheck = () => {
    startTransition(async () => {
      const res = await checkInvoiceCompleteness(invoiceData);
      setResult(res);
    });
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>AI Completeness Check</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Use our AI assistant to check for common mistakes, missing information, and potential omissions before sending your invoice.
          </p>
          <Button onClick={handleCheck} disabled={isPending} className="w-full">
            {isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Analyzing...
              </>
            ) : (
              'Check Invoice with AI'
            )}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle>AI Analysis Results</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant={result.isComplete ? 'default' : 'destructive'}>
              {result.isComplete ? <CheckCircle className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
              <AlertTitle>{result.isComplete ? 'Invoice is Complete' : 'Invoice is Incomplete'}</AlertTitle>
              <AlertDescription>
                {result.reasoning}
              </AlertDescription>
            </Alert>

            {result.missingFields && result.missingFields.length > 0 && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Missing Fields</AlertTitle>
                <AlertDescription>
                  The following required fields are missing:
                  <div className="flex flex-wrap gap-2 mt-2">
                    {result.missingFields.map((field, i) => <Badge key={i} variant="destructive">{field}</Badge>)}
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {result.potentialOmissions && result.potentialOmissions.length > 0 && (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Potential Omissions</AlertTitle>
                <AlertDescription>
                  The AI suggests you might want to consider adding the following:
                  <ul className="list-disc pl-5 mt-2">
                    {result.potentialOmissions.map((omission, i) => <li key={i}>{omission}</li>)}
                  </ul>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
