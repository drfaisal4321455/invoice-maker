'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from '@/components/ui/sidebar';
import { LayoutDashboard, FileText, Users, Package, Settings, FilePlus, Banknote } from 'lucide-react';
import { Button } from './ui/button';

const menuItems = [
  {
    href: '/dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
  },
  {
    href: '/invoices',
    label: 'Invoices',
    icon: FileText,
  },
  {
    href: '/customers',
    label: 'Customers',
    icon: Users,
  },
  {
    href: '/customer-balances',
    label: 'Balances',
    icon: Banknote,
  },
  {
    href: '/items',
    label: 'Items',
    icon: Package,
  },
  {
    href: '/settings',
    label: 'Settings',
    icon: Settings,
  },
];

export function MainNav() {
  const pathname = usePathname();

  return (
    <div className="flex flex-col p-2 gap-2 h-full">
      <Button asChild>
        <Link href="/invoices/new" className="flex items-center gap-2">
          <FilePlus />
          <span className="group-data-[collapsible=icon]:hidden">New Invoice</span>
        </Link>
      </Button>
      <SidebarMenu className="flex-1">
        {menuItems.map((item) => (
          <SidebarMenuItem key={item.href}>
            <SidebarMenuButton
              asChild
              isActive={pathname.startsWith(item.href)}
              tooltip={{ children: item.label, side: 'right' }}
            >
              <Link href={item.href}>
                <item.icon />
                <span>{item.label}</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        ))}
      </SidebarMenu>
    </div>
  );
}
