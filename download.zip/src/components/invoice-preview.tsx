'_x_client';

import { company, items } from "@/lib/data";
import { formatCurrency, cn } from "@/lib/utils";
import Image from "next/image";
import type { z } from 'zod';
import type { createInvoiceSchema } from "./invoice-form";
import type { Customer } from "@/lib/definitions";
import React from "react";

type InvoicePreviewProps = {
  invoiceData: z.infer<typeof createInvoiceSchema>;
  customers: Customer[];
  templateClassName: string;
};

export const InvoicePreview = React.forwardRef<HTMLDivElement, InvoicePreviewProps>(({ invoiceData, customers, templateClassName }, ref) => {
  const customer = customers.find(c => c.id === invoiceData.customerId);

  const subtotal = invoiceData.items.reduce((acc, item) => acc + (item.quantity * item.price), 0);
  const discountAmount = subtotal * (invoiceData.globalDiscount / 100);
  const subtotalAfterDiscount = subtotal - discountAmount;
  const totalTax = invoiceData.items.reduce((acc, item) => {
    const product = items.find(p => p.id === item.itemId);
    return acc + (item.quantity * item.price * (product?.taxRate || 0));
  }, 0);
  const total = subtotalAfterDiscount + totalTax + invoiceData.shipping;

  return (
    <div ref={ref} className={cn("bg-white text-black p-8 rounded-lg shadow-lg max-w-4xl mx-auto my-8 print-container", templateClassName)}>
      <header className="flex justify-between items-start pb-8 border-b-2">
        <div className="space-y-2">
          <Image src={company.logoUrl} alt={company.name} width={100} height={100} className="rounded-md" data-ai-hint="company logo" />
          <h1 className="text-3xl font-bold">{company.name}</h1>
          <p>{company.address}</p>
          <p>{company.email}</p>
          <p>{company.phone}</p>
        </div>
        <div className="text-right">
          <h2 className="text-4xl font-bold uppercase">Invoice</h2>
          <p className="mt-2">Invoice #: {invoiceData.invoiceNumber}</p>
          <p>Date Issued: {new Date(invoiceData.issueDate).toLocaleDateString()}</p>
          <p>Date Due: {new Date(invoiceData.dueDate).toLocaleDateString()}</p>
        </div>
      </header>

      <section className="my-8">
        <h3 className="font-semibold mb-2">Bill To:</h3>
        <p className="font-bold">{customer?.name}</p>
        <p>{customer?.address}</p>
        <p>{customer?.email}</p>
      </section>

      <section>
        <table className="w-full text-left">
          <thead>
            <tr>
              <th className="p-3 text-sm font-semibold">Item</th>
              <th className="p-3 text-sm font-semibold text-center">Qty</th>
              <th className="p-3 text-sm font-semibold text-right">Price</th>
              <th className="p-3 text-sm font-semibold text-right">Total</th>
            </tr>
          </thead>
          <tbody>
            {invoiceData.items.map((item, index) => {
              const product = items.find(p => p.id === item.itemId);
              return (
                <tr key={index} className="border-b">
                  <td className="p-3">{product?.description}</td>
                  <td className="p-3 text-center">{item.quantity}</td>
                  <td className="p-3 text-right">{formatCurrency(item.price, company.currency)}</td>
                  <td className="p-3 text-right">{formatCurrency(item.quantity * item.price, company.currency)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </section>

      <section className="flex justify-end mt-8">
        <div className="w-full max-w-xs space-y-3">
          <div className="flex justify-between">
            <span>Subtotal</span>
            <span>{formatCurrency(subtotal, company.currency)}</span>
          </div>
          {invoiceData.globalDiscount > 0 && (
            <div className="flex justify-between">
              <span>Discount ({invoiceData.globalDiscount}%)</span>
              <span>- {formatCurrency(discountAmount, company.currency)}</span>
            </div>
          )}
          <div className="flex justify-between">
            <span>Tax</span>
            <span>{formatCurrency(totalTax, company.currency)}</span>
          </div>
          {invoiceData.shipping > 0 && (
            <div className="flex justify-between">
              <span>Shipping</span>
              <span>{formatCurrency(invoiceData.shipping, company.currency)}</span>
            </div>
          )}
          <div className="border-t-2 pt-3 mt-3 flex justify-between font-bold text-lg">
            <span>Total</span>
            <span>{formatCurrency(total, company.currency)}</span>
          </div>
        </div>
      </section>

      <footer className="mt-16 text-center text-sm">
        <p>Thank you for your business!</p>
        <p>{company.name} | {company.taxInfo}</p>
      </footer>
    </div>
  );
});

InvoicePreview.displayName = 'InvoicePreview';
