// src/ai/flows/invoice-completeness-check.ts
'use server';

/**
 * @fileOverview This file defines a Genkit flow for checking the completeness of an invoice using AI.
 *
 * - invoiceCompletenessCheck: A function that checks the completeness of an invoice.
 * - InvoiceCompletenessCheckInput: The input type for the invoiceCompletenessCheck function.
 * - InvoiceCompletenessCheckOutput: The return type for the invoiceCompletenessCheck function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const InvoiceCompletenessCheckInputSchema = z.object({
  companyName: z.string().describe('The name of the company issuing the invoice.'),
  customerName: z.string().describe('The name of the customer receiving the invoice.'),
  invoiceNumber: z.string().describe('The invoice number.'),
  issueDate: z.string().describe('The date the invoice was issued (YYYY-MM-DD).'),
  dueDate: z.string().describe('The date the invoice is due (YYYY-MM-DD).'),
  items: z
    .array(
      z.object({
        sku: z.string().describe('The stock keeping unit of the item.'),
        description: z.string().describe('A description of the item.'),
        quantity: z.number().describe('The quantity of the item.'),
        price: z.number().describe('The price of the item.'),
        taxRate: z.number().optional().describe('The tax rate applied to the item.'),
        discount: z.number().optional().describe('The discount applied to the item.'),
      })
    )
    .describe('A list of items included in the invoice.'),
  subtotal: z.number().describe('The subtotal of the invoice before taxes and discounts.'),
  globalDiscount: z.number().optional().describe('A global discount applied to the invoice.'),
  shipping: z.number().optional().describe('The shipping cost of the invoice.'),
  total: z.number().describe('The total amount due on the invoice.'),
});

export type InvoiceCompletenessCheckInput = z.infer<
  typeof InvoiceCompletenessCheckInputSchema
>;

const InvoiceCompletenessCheckOutputSchema = z.object({
  isComplete: z.boolean().describe('Whether the invoice is complete and ready to send.'),
  missingFields: z.array(z.string()).describe('A list of any missing fields on the invoice.'),
  potentialOmissions: z
    .array(z.string())
    .describe('A list of any potential omissions or errors on the invoice.'),
  reasoning: z
    .string()
    .describe(
      'A detailed explanation of the AI reasoning for the completeness check, including identified omissions and errors.'
    ),
});

export type InvoiceCompletenessCheckOutput = z.infer<
  typeof InvoiceCompletenessCheckOutputSchema
>;

export async function invoiceCompletenessCheck(
  input: InvoiceCompletenessCheckInput
): Promise<InvoiceCompletenessCheckOutput> {
  return invoiceCompletenessCheckFlow(input);
}

const prompt = ai.definePrompt({
  name: 'invoiceCompletenessCheckPrompt',
  input: {schema: InvoiceCompletenessCheckInputSchema},
  output: {schema: InvoiceCompletenessCheckOutputSchema},
  prompt: `You are an AI assistant specialized in reviewing invoices for completeness and accuracy.

  Analyze the following invoice data and determine if the invoice is complete and ready to be sent to the customer.
  Identify any missing fields, potential omissions, or errors.

  Company Name: {{{companyName}}}
  Customer Name: {{{customerName}}}
  Invoice Number: {{{invoiceNumber}}}
  Issue Date: {{{issueDate}}}
  Due Date: {{{dueDate}}}
  Items: {{#each items}}- SKU: {{{sku}}}, Description: {{{description}}}, Quantity: {{{quantity}}}, Price: {{{price}}}, Tax Rate: {{{taxRate}}}, Discount: {{{discount}}} {{/each}}
  Subtotal: {{{subtotal}}}
  Global Discount: {{{globalDiscount}}}
  Shipping: {{{shipping}}}
  Total: {{{total}}}

  Provide a detailed explanation of your reasoning, including any identified omissions and errors.
  If the invoice is missing any critical information, populate the missingFields field with a list of strings of the field names.
  If there are potential omissions based on the type of invoice such as missing addresses or contact information, populate the potentialOmissions field with a list of strings describing the omissions.

  Based on your analysis, set the isComplete field to true if the invoice is complete and ready to send, or false otherwise.
`,
});

const invoiceCompletenessCheckFlow = ai.defineFlow(
  {
    name: 'invoiceCompletenessCheckFlow',
    inputSchema: InvoiceCompletenessCheckInputSchema,
    outputSchema: InvoiceCompletenessCheckOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);

