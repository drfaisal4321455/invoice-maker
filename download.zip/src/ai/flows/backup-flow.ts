'use server';

/**
 * @fileOverview A Genkit flow for handling data backups.
 *
 * - triggerBackup: A function that initiates the backup process.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import {
  getFirestore,
  collection,
  getDocs,
  getDoc,
  doc,
} from 'firebase/firestore';
import { getStorage, ref, uploadString } from 'firebase/storage';
import { db } from '@/lib/firebase';

async function getAllCollectionData(collectionName: string) {
  const querySnapshot = await getDocs(collection(db, collectionName));
  const data: any[] = [];
  querySnapshot.forEach((doc) => {
    data.push({ id: doc.id, ...doc.data() });
  });
  return data;
}

export const triggerBackup = ai.defineFlow(
  {
    name: 'triggerBackup',
    inputSchema: z.void(),
    outputSchema: z.object({
      success: z.boolean(),
      message: z.string(),
      backupPaths: z.array(z.string()).optional(),
    }),
  },
  async () => {
    const storage = getStorage();
    const timestamp = new Date();
    const dateFolder = timestamp.toISOString().split('T')[0];

    try {
      // 1. Fetch all customers
      const customers = await getAllCollectionData('customers');

      // 2. Fetch all invoices for each customer
      const allInvoices: any[] = [];
      for (const customer of customers) {
        const invoicesSnapshot = await getDocs(
          collection(db, `customers/${customer.id}/invoices`)
        );
        invoicesSnapshot.forEach((invoiceDoc) => {
          allInvoices.push({
            id: invoiceDoc.id,
            customerId: customer.id,
            ...invoiceDoc.data(),
          });
        });
      }

      // 3. Prepare data for backup
      const backupData = {
        customers,
        invoices: allInvoices,
      };

      // 4. Upload to Cloud Storage
      const backupPaths: string[] = [];

      for (const key in backupData) {
        const jsonData = JSON.stringify(
          (backupData as any)[key],
          null,
          2
        );
        const storageRef = ref(
          storage,
          `backups/${dateFolder}/${key}.json`
        );
        await uploadString(storageRef, jsonData, 'raw', {
          contentType: 'application/json',
        });
        backupPaths.push(storageRef.fullPath);
      }

      return {
        success: true,
        message: 'Backup completed successfully.',
        backupPaths,
      };
    } catch (error: any) {
      console.error('Backup failed:', error);
      return {
        success: false,
        message: `Backup failed: ${error.message}`,
      };
    }
  }
);
